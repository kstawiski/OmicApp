<?php
header("Location: /modules/home/");
?>